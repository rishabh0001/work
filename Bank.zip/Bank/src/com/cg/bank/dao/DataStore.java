package com.cg.bank.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bank.dto.Customer;

public class DataStore {
	private static Map<String, Customer> customer;
	static Map<String, Customer> createCollection(){
		if(customer == null)
			customer = new HashMap<>();		
		customer.put("7055178203", new Customer("7055178203","Rishabh Srivastava",25,100000));
		customer.put("7055178202", new Customer("7055178202","Ankita Singh",25,850000));
		customer.put("7055178201", new Customer("7055178201","Neha Dixit",22,104500));
		customer.put("7055178200", new Customer("7055178200","Shahid Khan",21,890000));
		
		return customer;		
	}

}
